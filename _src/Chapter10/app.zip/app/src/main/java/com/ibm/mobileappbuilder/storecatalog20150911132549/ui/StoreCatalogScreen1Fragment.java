

package com.ibm.mobileappbuilder.storecatalog20150911132549.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPush;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPPushNotificationListener;
import com.ibm.mobilefirstplatform.clientsdk.android.push.api.MFPSimplePushNotification;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * StoreCatalogScreen1Fragment menu fragment.
 */
public class StoreCatalogScreen1Fragment extends ibmmobileappbuilder.ui.MenuFragment implements MFPPushNotificationListener{

    private MFPPush push = null;
    private Context _this;
    private static final String TAG = "StoreCatalogScreen1Frag";
    /**
     * Default constructor
     */
    public StoreCatalogScreen1Fragment(){
        super();
    }

    // Factory method
    public static StoreCatalogScreen1Fragment newInstance(Bundle args) {
        StoreCatalogScreen1Fragment fragment = new StoreCatalogScreen1Fragment();

        fragment.setArguments(args);
        return fragment;
    }


    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
        _this = getActivity();

        // MFPPush is initialized in PushNotificationsApplication.class
        push = MFPPush.getInstance();


        // Option for receiving push notifications
        push.listen(this);
    }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("Lip Balms")
            .setIcon(R.drawable.jpg_lbgreentea353)
            .setAction(new StartActivityAction(LipBalmsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Soaps")
            .setIcon(R.drawable.png_soaps511)
            .setAction(new StartActivityAction(SoapsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
                        .setLabel("Body Scrubs")
                        .setIcon(R.drawable.png_screenshot20160816at11825pm255)
                        .setAction(new StartActivityAction(BodyScrubsActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_list;
    }

    @Override
    public int getItemLayout() {
        return R.layout.storecatalogscreen1_item;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (push != null) {
            push.hold();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (push != null) {
            push.listen(this);
        }
    }

    public void showAlertMsg(final String title, final String msg) {

        Runnable run = new Runnable() {
            @Override
            public void run() {
                // Create an AlertDialog Builder, and configure alert
                AlertDialog.Builder builder = new AlertDialog.Builder(_this);
                builder.setTitle(title)
                        .setMessage(msg)
                        .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.i(TAG, "Okay was pressed");
                            }
                        });

                // Create the AlertDialog
                AlertDialog dialog = builder.create();

                // Display the dialog
                dialog.show();
            }
        };

        getActivity().runOnUiThread(run);
    }

    @Override
    public void onReceive(MFPSimplePushNotification mfpSimplePushNotification) {
        Log.i("Push Notifications", mfpSimplePushNotification.getAlert());

        String alert = "" + mfpSimplePushNotification.getAlert();
        //String alertID = "ID: " + mfpSimplePushNotification.getId();
        //String alertPayload = "Payload: " + mfpSimplePushNotification.getPayload();

        // Show the received notification in an AlertDialog
        //showAlertMsg("Push Notifications", alert + "\n" + alertID + "\n" + alertPayload);
        showAlertMsg("Arudra Store Catalog", alert);
    }
}

