
package com.ibm.mobileappbuilder.storecatalog20150911132549.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storecatalog20150911132549.ds.ProductsDSItem;
import com.ibm.mobileappbuilder.storecatalog20150911132549.ds.ProductsDS;

public class SoapsDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<ProductsDSItem> implements ShareBehavior.ShareListener  {

    private Datasource<ProductsDSItem> datasource;
    public static SoapsDetailFragment newInstance(Bundle args){
        SoapsDetailFragment fr = new SoapsDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public SoapsDetailFragment(){
        super();
    }

    @Override
    public Datasource<ProductsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ProductsDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.soapsdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ProductsDSItem item, View view) {
        if (item.name != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.name);
            
        }
        
        ImageView view1 = (ImageView) view.findViewById(R.id.view1);
        URL view1Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view1Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view1.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view1Media.toExternalForm())
                                   .withTargetView(view1)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view1.setImageDrawable(null);
        }
        if (item.description != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.description);
            
        }
        if (item.price != null && item.rating != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText("Rs. " + item.price + "  " + item.rating);
            
        }
        
        ImageView view4 = (ImageView) view.findViewById(R.id.view4);
        URL view4Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.thumbnail);
        if(view4Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view4.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view4Media.toExternalForm())
                                   .withTargetView(view4)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view4.setImageDrawable(null);
        }
    }

    @Override
    protected void onShow(ProductsDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
    @Override
    public void onShare() {
        ProductsDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.name != null ? item.name : "" ) + "\n" +
                    (item.description != null ? item.description : "" ) + "\n" +
                    (item.price != null && item.rating != null ? "Rs. " + item.price + "  " + item.rating : "" ));
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

